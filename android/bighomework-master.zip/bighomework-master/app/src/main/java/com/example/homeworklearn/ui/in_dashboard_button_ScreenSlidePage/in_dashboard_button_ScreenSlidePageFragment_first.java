package com.example.homeworklearn.ui.in_dashboard_button_ScreenSlidePage;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.example.homeworklearn.R;

/**
 * @ClassName : ScreenSlidePageFragment_first
 * @Author : 骆发茂
 * @Date: 2021/4/13 8:14
 * @Description :
 */
public class in_dashboard_button_ScreenSlidePageFragment_first extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.in_dashboard_button_fragment_screen_slide_page_firstpage, container, false);
        return root;
    }


}

