package com.example.meituan.utils;
public class Constant {
    public static final String WEB_SITE = "http://192.168.100.119:8080/order";//内网接口，改为自己电脑的实际ip
    public static final String REQUEST_SHOP_URL = "/shop_list_data.json";  //店铺列表接口
}
